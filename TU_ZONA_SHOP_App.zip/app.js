# Archivo principal de la aplicación
import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ShoppingCart, Search, CreditCard, Star, Gift, Gamepad2 } from "lucide-react";

const products = [
  { id: 1, name: "Sneakers Urban", price: 49.99, image: "https://via.placeholder.com/150", discount: 10 },
  { id: 2, name: "Mochila Minimalista", price: 39.99, image: "https://via.placeholder.com/150", discount: 5 },
  { id: 3, name: "Auriculares Bluetooth", price: 29.99, image: "https://via.placeholder.com/150", discount: 15 },
  { id: 4, name: "Camiseta Oversize", price: 19.99, image: "https://via.placeholder.com/150", discount: 0 },
];

const coupons = {
  "JOVEN10": 10,
  "DESCUENTO15": 15,
  "OFERTA20": 20,
};

export default function TUZONASHOP() {
  const [cart, setCart] = useState([]);
  const [search, setSearch] = useState("");
  const [recommended, setRecommended] = useState([]);
  const [coupon, setCoupon] = useState("");
  const [discount, setDiscount] = useState(0);
  const [gameTime, setGameTime] = useState(0);
  const [unlockedCoupon, setUnlockedCoupon] = useState("");
  const [isPlaying, setIsPlaying] = useState(false);

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const handlePayment = () => {
    alert("Procesando pago... Gracias por tu compra!");
    setCart([]);
    setDiscount(0);
    setCoupon("");
  };

  const applyCoupon = () => {
    if (coupons[coupon]) {
      setDiscount(coupons[coupon]);
      alert(`Cupón aplicado: ${coupons[coupon]}% de descuento!`);
    } else {
      alert("Cupón no válido");
    }
  };

  useEffect(() => {
    if (cart.length > 0) {
      const lastItem = cart[cart.length - 1];
      const relatedProducts = products.filter(
        (p) => p.id !== lastItem.id && !cart.includes(p)
      );
      setRecommended(relatedProducts.slice(0, 2));
    } else {
      setRecommended([]);
    }
  }, [cart]);

  useEffect(() => {
    if (isPlaying) {
      const timer = setInterval(() => {
        setGameTime((prev) => prev + 1);
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isPlaying]);

  useEffect(() => {
    if (gameTime >= 30 && !unlockedCoupon) {
      setUnlockedCoupon("JUEGO10");
      alert("¡Felicidades! Has desbloqueado un cupón de 10% de descuento: JUEGO10");
    }
  }, [gameTime, unlockedCoupon]);

  const total = cart.reduce((sum, item) => sum + item.price, 0);
  const discountedTotal = total - (total * discount) / 100;

  return (
    <div className="p-4 max-w-lg mx-auto bg-gradient-to-b from-blue-500 via-purple-500 to-pink-500 text-white min-h-screen">
      <div className="flex justify-center mb-4">
        <img src="/logo_tu_zona_shop.png" alt="TU ZONA SHOP" className="w-32 h-auto" />
      </div>
      <div className="flex items-center mb-4">
        <Input
          placeholder="Buscar productos..."
          onChange={(e) => setSearch(e.target.value.toLowerCase())}
          className="bg-white text-black rounded-lg p-2"
        />
        <Button className="ml-2 bg-yellow-400 hover:bg-yellow-500 text-black">
          <Search className="w-5 h-5" />
        </Button>
      </div>
      <Card className="mt-4 p-4 bg-white text-black rounded-lg shadow-lg">
        <CardContent>
          <h3 className="text-lg font-semibold flex items-center">
            <Gamepad2 className="w-5 h-5 mr-2 text-purple-500" /> Juegos de Moda y Estilo
          </h3>
          <p className="text-sm text-gray-500">Juega y desbloquea cupones de descuento.</p>
          <Button onClick={() => setIsPlaying(!isPlaying)} className="mt-2 bg-blue-400 hover:bg-blue-500 text-black">
            {isPlaying ? "Detener Juego" : "Jugar Ahora"}
          </Button>
          <p className="mt-2 text-black">Tiempo jugado: {gameTime} segundos</p>
          {unlockedCoupon && <p className="text-green-500 font-bold">Cupón desbloqueado: {unlockedCoupon}</p>}
        </CardContent>
      </Card>
    </div>
  );
}
